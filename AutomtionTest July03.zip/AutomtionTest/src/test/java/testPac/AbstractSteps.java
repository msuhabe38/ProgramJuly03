package testPac;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.cucumber.java.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AbstractSteps {

    public static WebDriver driver;
    public ExtentReports reports;

    public ExtentSparkReporter extentSpRpt;
    public static ExtentTest logger;

    public static WebDriver getDriver(){
        if(driver==null) {
            driver = new ChromeDriver();
        }
        return driver;
    }


    @Before
    public void launch(Scenario sc){
        System.setProperty("webdriver.chrome.driver","C:\\Users\\User\\chromedriver\\chromedriver.exe");
        startTest(sc);

    }

    @After
    public void terminate(){
        if(driver!=null) {
            driver.quit();
        }
        reports.flush();
    }



    public void startTest(Scenario sc){

        reports = new ExtentReports();
        Date dt = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd.hhmmss.SSS");
        String afterFormat = sdf.format(dt);
        String[] scenarioName = sc.getName().split(" ");
        if(scenarioName[0].contains("API"))
            extentSpRpt = new ExtentSparkReporter(new File(System.getProperty("user.dir") + "\\Reports\\API\\Automation-report-"+afterFormat+".html"));
        else
            extentSpRpt = new ExtentSparkReporter(new File(System.getProperty("user.dir") + "\\Reports\\Store\\Automation-report-"+afterFormat+".html"));

        reports.attachReporter(extentSpRpt);

        logger = reports.createTest(scenarioName[0]);
    }


}
