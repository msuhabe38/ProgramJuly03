package testPac;

import impl.restAPI;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class StepDefinitionAPI {

    restAPI api = new restAPI();

    @Given("The API connect is established")
    public void the_api_connect_is_established() {
        api.getURL();
    }
    @Then("Fetch the values of Page {string} and print")
    public void fetch_the_values_of_Page_and_print(String pageNum) {
        api.getResponseBody(pageNum);
    }

    @Then("Fetch the First name and Email of all Users in Page {string}")
    public void fetch_the_first_name_and_email_of_all_users_in_page(String pageNum) {
        api.getFirstNameandEMail(pageNum);
    }

    @Then("Fetch the user details by giving ID")
    public void fetch_the_user_details_by_giving_id(DataTable dataT) {
        api.getDataBasedonID(dataT,"1");
    }

    @Then("Fetch the response code for GET and user details for Page {string}")
    public void fetch_the_response_code_for_get_and_user_details(String pageNum) {
        api.validateResponseCode(pageNum);
    }
    @Then("Post the new user and retrieve the ID and Response Code")
    public void post_the_new_user_and_retrieve_the_id() {
        api.postUser();
    }

    @Then("Update the new user details and retrieve the Response Code")
    public void update_the_new_user_details_and_retrieve_the_response_code() {
        api.putUserDetails();
    }

}
