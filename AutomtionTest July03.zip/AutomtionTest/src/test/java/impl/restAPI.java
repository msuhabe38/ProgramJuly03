package impl;

import com.aventstack.extentreports.Status;
import io.cucumber.datatable.DataTable;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;
import testPac.AbstractSteps;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class restAPI extends AbstractSteps {

    public void getResponseBody(String pageNum){
        Response res = given().queryParam("page",pageNum).when().get("/users");
        System.out.println("Response Body of Page "+pageNum+": "+res.asString());
        if(res.asString()!=null){
            logger.log(Status.PASS,"Response Body of Page "+pageNum+": "+res.asString());
        }else{
            logger.log(Status.FAIL,"Response Body of Page Not Loaded");
        }
    }

    public void getFirstNameandEMail(String pageNum){
        Response res = given().queryParam("page",pageNum).when().get("/users");
        JsonPath j = new JsonPath(res.asString());
        String fName = j.getString("data.first_name");
        String eMail = j.getString("data.email");

            System.out.println("FirstNames are:" + fName);
            System.out.println("emails are:" + eMail);

        if(fName!=null){
            logger.log(Status.PASS,"FirstNames are:" + fName);
        }else{
            logger.log(Status.FAIL,"Error: Not able to read first names");
        }

        if(eMail!=null){
            logger.log(Status.PASS,"Emails Id's are:" + eMail);
        }else{
            logger.log(Status.FAIL,"Error: Not able to read email id's");
        }

        }

        public void getDataBasedonID(DataTable dt,String pageNum){
            Response res = given().queryParam("page",pageNum).when().get("/users");
            JsonPath jp = new JsonPath(res.asString());
            int total_pages = jp.getInt("total_pages");
            int perPageData = jp.getInt("per_page");
            int count=0;
            Map<Integer,String> apiData = new HashMap<>();
            for(int i=1;i<=total_pages;i++){
                Response res1 = given().queryParam("page",i).when().get("/users");
                JsonPath jp1 = new JsonPath(res1.asString());
                for(int j=0;j<perPageData;j++){
                    apiData.put(count+1,jp1.getString("data["+j+"]"));
                    count++;
                }
            }


            for(Map<String,Integer> map : dt.asMaps(String.class,Integer.class)){
                if(!map.isEmpty() && map!=null && map.get("Id")!=null && apiData.get(map.get("Id"))!=null) {
                    System.out.println(apiData.get(map.get("Id")));
                    logger.log(Status.PASS, "User details for ID " + map.get("Id") +":" + apiData.get(map.get("Id")));
                } else{
                    logger.log(Status.FAIL, "User details for ID " + map.get("Id") + " not found");
                }
                }



        }

        public void validateResponseCode(String pageNum){
            Response res = given().queryParam("page",pageNum).when().get("/users");
            int respCode = res.statusCode();
            Assert.assertEquals(respCode,200);
            if(respCode==200) {
                System.out.println("Validated the Response Code for Page "+pageNum+" is "+respCode);
                logger.log(Status.PASS, "Validated the Response Code for Page "+pageNum+" is "+respCode);
            } else{
                System.out.println("Error: Validated the Response Code for Page "+pageNum+" is "+respCode);
                logger.log(Status.FAIL, "Error: Validated the Response Code for Page "+pageNum+" is "+respCode);
            }


         }


        public void getURL(){
            RestAssured.baseURI = "https://reqres.in/api";
        }

        public void postUser(){
            Response res = null;
            String requestBody = "{\n" +
                    "            \"email\": \"user1.user@reqres.in\",\n" +
                    "            \"first_name\": \"user1\",\n" +
                    "            \"last_name\": \"user\"\n" +
                    "        }";
            try{
                 res = given().body(requestBody).post("/users");
            }catch(Exception e){
                e.printStackTrace();
            }

            if(res.asString()!=null) {
                System.out.println(res.asString());
                logger.log(Status.PASS, "Validated Response Message for POST msg is"+ res.asString());
            }else{
                logger.log(Status.FAIL, "Response Message is incorrect");

            }

            int respCode = res.statusCode();
            Assert.assertEquals(respCode,201);
            if(respCode==201) {
                System.out.println("Validated the Response Code is "+respCode);
                logger.log(Status.PASS, "Validated the Response Code is "+respCode);
            } else{
                System.out.println("Error: Validated the Response Code is "+respCode);
                logger.log(Status.FAIL, "Error: Validated the Response Code is "+respCode);
            }


        }

    public void putUserDetails(){
        Response res = null;
        String requestBody = "{\n" +
                "            \"email\": \"user1.usermail@reqres.in\",\n" +
                "        }";
        try{
            res = given().body(requestBody).put("/users/151");
        }catch(Exception e){
            e.printStackTrace();
        }

        if(res.asString()!=null) {
            System.out.println(res.asString());
            logger.log(Status.PASS, "Validated Response Message for PUT msg is"+ res.asString());
        }else{
            logger.log(Status.FAIL, "Response Message is incorrect");

        }

        int respCode = res.statusCode();
        Assert.assertEquals(respCode,200);
        if(respCode==200) {
            System.out.println("Validated the Response Code is "+respCode);
            logger.log(Status.PASS, "Validated the Response Code is "+respCode);
        } else{
            System.out.println("Error: Validated the Response Code is "+respCode);
            logger.log(Status.FAIL, "Error: Validated the Response Code is "+respCode);
        }


    }

}
