Use TestRunner.java to run the program
Use Reports > extent-report.html to check the execution report